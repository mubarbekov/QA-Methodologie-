import java.util.Scanner;

public class LoginTest {

    // This method check is password and username is true?
    public static boolean login(String username, String password) {
        String correctUsername = "test1";
        String correctPassword = "Test12456";
        return username.equals(correctUsername) && password.equals(correctPassword);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // These is successful example
        System.out.println("=== Test Case 1: Successful Login ===");
        if (login("test1", "Test12456")) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Login failed.");
        }

        // this unsuccessful example
        System.out.println("=== Test Case 2: Unsuccessful Login ===");
        if (login("test1", "test1234")) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Login failed.");
        }

        // option for user to try
        System.out.println("=== Try Your Own Login ===");
        System.out.print("Enter username: ");
        String user = scanner.nextLine();
        System.out.print("Enter password: ");
        String pass = scanner.nextLine();

        if (login(user, pass)) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Login failed.");
        }

        scanner.close();
    }
}
