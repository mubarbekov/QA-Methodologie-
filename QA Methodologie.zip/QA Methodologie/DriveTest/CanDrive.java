public class CanDrive {  // public class name
    public static boolean canDrive(int age) { // static method that integer is age
        int drivingAge = 16; // The Driving Age that equals 16
        return age >= drivingAge; // Return True if Integer equals or bigger Driving Age
    }
}
